import React from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Swal from 'sweetalert2';

function Dashboard() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    Swal.fire({
      title: 'Logging out...',
      text: 'You will be redirected to the login page.',
      icon: 'info',
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
      willClose: () => {
        logout();
        navigate('/login');
      }
    });
  };

  const isActive = (path) => location.pathname === path;

  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 bg-white shadow-md">
        <div className="p-4 bg-indigo-600">
          <h1 className="text-2xl font-semibold text-white">Dashboard</h1>
        </div>
        <nav className="mt-4">
          <Link
            to="/"
            className={`block py-2 px-4 text-gray-700 hover:bg-indigo-100 hover:text-indigo-600 transition-colors duration-200 ${
              isActive('/') ? 'bg-indigo-100 text-indigo-600 border-r-4 border-indigo-600' : ''
            }`}
          >
            Products
          </Link>
          <Link
            to="/categories"
            className={`block py-2 px-4 text-gray-700 hover:bg-indigo-100 hover:text-indigo-600 transition-colors duration-200 ${
              isActive('/categories') ? 'bg-indigo-100 text-indigo-600 border-r-4 border-indigo-600' : ''
            }`}
          >
            Categories
          </Link>
        </nav>
        <button
          onClick={handleLogout}
          className="block w-full py-2 px-4 mt-4 text-left text-gray-700 hover:bg-red-100 hover:text-red-600 transition-colors duration-200"
        >
          Logout
        </button>
      </aside>
      <main className="flex-1 p-8 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}

export default Dashboard;

