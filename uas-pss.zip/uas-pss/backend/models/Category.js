import mongoose from 'mongoose';

const categorySchema = new mongoose.Schema({
  category_id: { type: String, required: true, unique: true },
  nama: { type: String, required: true },
});

export default mongoose.model('Category', categorySchema);

