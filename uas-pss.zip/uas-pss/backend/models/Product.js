import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  product_id: { type: String, required: true, unique: true },
  nama: { type: String, required: true },
  category_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  harga: { type: Number, required: true },
  jml_stok: { type: Number, required: true },
});

export default mongoose.model('Product', productSchema);

